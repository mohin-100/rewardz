import { Injectable } from '@angular/core';
import { Category } from '../models/category.model';
import { Item } from '../models/item.mode';

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  // Array of items with predefined data
  private items: Item[] = [
    { 
      id: 987, 
      title: 'Reward Name', 
      image: 'assets/images/image1.png', 
      points: 150, 
      category: 'e-Voucher',
      quantity: 14, 
      validUntil: '2024-12-31T00:00:00', 
      lowQuantity: 10 
    },
    { 
      id: 2, 
      title: 'Dairy Farm $20', 
      image: 'assets/images/image2.png', 
      points: 2, 
      category: 'e-Voucher',
      quantity: 0, 
      validUntil: '2024-12-31T00:00:00', 
      lowQuantity: 10 
    },
    { 
      id: 3, 
      title: 'Software Testing', 
      image: 'assets/images/image3.png', 
      points: 5, 
      category: 'Products',
      quantity: 14, 
      validUntil: '2024-12-31T00:00:00', 
      lowQuantity: 15 
    },
    { 
      id: 4, 
      title: 'Health & Fitness Tracker', 
      image: 'assets/images/image1.png', 
      points: 100, 
      category: 'Products',
      quantity: 20, 
      validUntil: '2025-06-30T00:00:00', 
      lowQuantity: 5 
    },
    { 
      id: 5, 
      title: 'Amazon Gift Card $50', 
      image: 'assets/images/image2.png', 
      points: 200, 
      category: 'e-Voucher',
      quantity: 30, 
      validUntil: '2024-12-31T00:00:00', 
      lowQuantity: 15 
    },
    { 
      id: 6, 
      title: 'Laptop Stand', 
      image: 'assets/images/image3.png', 
      points: 10, 
      category: 'Products',
      quantity: 25, 
      validUntil: '2025-03-15T00:00:00', 
      lowQuantity: 10 
    },
    { 
      id: 7, 
      title: 'Starbucks Gift Card $30', 
      image: 'assets/images/image2.png', 
      points: 120, 
      category: 'e-Voucher',
      quantity: 50, 
      validUntil: '2025-01-31T00:00:00', 
      lowQuantity: 20 
    },
    { 
      id: 8, 
      title: 'Wireless Mouse', 
      image: 'assets/images/image1.png', 
      points: 25, 
      category: 'Products',
      quantity: 10, 
      validUntil: '2025-05-01T00:00:00', 
      lowQuantity: 3 
    },
    { 
      id: 9, 
      title: 'Gaming Headset', 
      image: 'assets/images/image3.png', 
      points: 300, 
      category: 'Products',
      quantity: 5, 
      validUntil: '2025-02-15T00:00:00', 
      lowQuantity: 2 
    },
    { 
      id: 10, 
      title: 'Spa Voucher $100', 
      image: 'assets/images/image2.png', 
      points: 500, 
      category: 'e-Voucher',
      quantity: 2, 
      validUntil: '2025-11-30T00:00:00', 
      lowQuantity: 1 
    },
    { 
      id: 11, 
      title: 'Travel Backpack', 
      image: 'assets/images/image1.png', 
      points: 60, 
      category: 'Products',
      quantity: 40, 
      validUntil: '2025-04-10T00:00:00', 
      lowQuantity: 5 
    },
    { 
      id: 12, 
      title: 'Online Course Subscription', 
      image: 'assets/images/image2.png', 
      points: 400, 
      category: 'e-Voucher',
      quantity: 15, 
      validUntil: '2024-12-31T00:00:00', 
      lowQuantity: 8 
    },
    { 
      id: 13, 
      title: 'Bluetooth Speaker', 
      image: 'assets/images/image3.png', 
      points: 80, 
      category: 'Products',
      quantity: 35, 
      validUntil: '2025-09-10T00:00:00', 
      lowQuantity: 10 
    },
    { 
      id: 14, 
      title: 'Fitness Band', 
      image: 'assets/images/image2.png', 
      points: 70, 
      category: 'Products',
      quantity: 50, 
      validUntil: '2025-07-20T00:00:00', 
      lowQuantity: 15 
    },
    { 
      id: 15, 
      title: 'Movie Night Voucher', 
      image: 'assets/images/image1.png', 
      points: 300, 
      category: 'e-Voucher',
      quantity: 10, 
      validUntil: '2025-12-25T00:00:00', 
      lowQuantity: 5 
    }
  ];

  // Array of categories with predefined data
  private categories: Category[] = [
    { name: 'e-Voucher', active: false },
    { name: 'Products', active: false },
    { name: 'Evergreen', active: false },
    { name: 'Fashion & Retail', active: false },
  ];

  // Method to get the list of items
  getItems(): Item[] {
    return this.items;
  }

  // Method to get the list of categories
  getCategories(): Category[] {
    return this.categories;
  }
}
