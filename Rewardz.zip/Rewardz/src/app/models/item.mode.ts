// Represents an item or product in the system
export interface Item {
  id: number;
  title: string;
  image: string;
  points: number;
  category: string;
  quantity: number;
  validUntil: string;
  lowQuantity: number;
}