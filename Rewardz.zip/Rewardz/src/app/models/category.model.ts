// Represents a product category
export interface Category {
  name: string;
  active: boolean;
}