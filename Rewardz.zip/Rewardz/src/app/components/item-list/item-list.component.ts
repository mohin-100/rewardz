import { Component, OnInit } from '@angular/core';
import { Category } from 'src/app/models/category.model';
import { Item } from 'src/app/models/item.mode';
import { ItemService } from 'src/app/services/item.service';

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.scss']
})
export class ItemListComponent implements OnInit {
  items: Item[] = [];
  categories: Category[] = [];
  filteredItems: Item[] = [];
  searchTerm: string = '';
  activeFilters: string[] = [];
  paginatedItems: Item[] = [];
  isSortDrawerOpen = false;
  itemsPerPage: number = 7;
  paginationOptions: number[] = [7, 14, 21, 28];
  currentPage: number = 1;

  constructor(private itemService: ItemService) {}

  // Fetch items and categories on init
  ngOnInit(): void {
    this.items = this.itemService.getItems();
    this.categories = this.itemService.getCategories();
    this.filteredItems = [...this.items];
    this.updatePagination();
  }

  // Toggle category filter
  toggleCategory(category: Category): void {
    category.active = !category.active;
    category.active ? this.activeFilters.push(category.name) : this.removeFilter(category.name);
    this.applyFilters();
  }

  // Remove filter by category
  removeFilter(filter: string): void {
    this.activeFilters = this.activeFilters.filter(f => f !== filter);
    const category = this.categories.find(cat => cat.name === filter);
    if (category) category.active = false;
    this.applyFilters();
  }

  // Apply category filters
  applyFilters(): void {
    const activeCategories = this.categories.filter(cat => cat.active).map(cat => cat.name);
    this.filteredItems = this.items.filter(item =>
      activeCategories.length ? activeCategories.includes(item.category) : true
    );
    this.updatePagination();
  }

  // Clear all active filters
  clearFilters(): void {
    this.categories.forEach(cat => (cat.active = false));
    this.activeFilters = [];
    this.filteredItems = [...this.items];
    this.updatePagination();
  }

  // Filter items based on search term
  onSearch(): void {
    this.filteredItems = this.items.filter(item =>
      item.title.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
    this.updatePagination();
  }

  // Toggle sort drawer visibility
  toggleSortDrawer(): void {
    this.isSortDrawerOpen = !this.isSortDrawerOpen;
  }

  // Apply sorting by title (A-Z or Z-A)
  applySort(order: string): void {
    this.filteredItems.sort((a, b) =>
      order === 'A-Z' ? a.title.localeCompare(b.title) : b.title.localeCompare(a.title)
    );
    this.isSortDrawerOpen = false;
    this.updatePagination();
  }

  // Update paginated items based on current page
  updatePagination(): void {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedItems = this.filteredItems.slice(startIndex, endIndex);
  }
}
